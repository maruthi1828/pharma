export interface Product {
  id: string;
  name: string;
  description: string;
  category: string;
  originalPrice: number;
  discountedPrice: number;
  image: string;
  inStock: boolean;
  rating: number;
  reviewCount: number;
  manufacturer: string;
  dosage: string;
  packSize: string;
}

export interface Review {
  id: string;
  productId: string;
  customerName: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
}