import React, { useState } from 'react';
import { Search, ShoppingCart, Menu, X, Phone, Mail } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-lg">
      {/* Top bar */}
      <div className="bg-blue-600 text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Phone size={14} />
              <span>+1-800-PHARMA-1</span>
            </div>
            <div className="flex items-center space-x-2">
              <Mail size={14} />
              <span>info@maruthipharma.com</span>
            </div>
          </div>
          <div className="hidden md:block">
            <span className="bg-green-500 px-3 py-1 rounded-full text-xs font-semibold">
              FREE SHIPPING ON ORDERS $50+
            </span>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="bg-blue-600 p-2 rounded-lg">
              <div className="w-8 h-8 bg-white rounded flex items-center justify-center">
                <span className="text-blue-600 font-bold text-xl">P</span>
              </div>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Maruthi Pharma</h1>
              <p className="text-sm text-gray-600">Trusted Healthcare Solutions</p>
            </div>
          </div>

          {/* Search bar - Desktop */}
          <div className="hidden md:flex flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <input
                type="text"
                placeholder="Search medicines, supplements..."
                className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <Search className="absolute left-3 top-2.5 text-gray-400" size={20} />
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <a href="#home" className="text-gray-700 hover:text-blue-600 font-medium">Home</a>
            <a href="#products" className="text-gray-700 hover:text-blue-600 font-medium">Products</a>
            <a href="#reviews" className="text-gray-700 hover:text-blue-600 font-medium">Reviews</a>
            <a href="#contact" className="text-gray-700 hover:text-blue-600 font-medium">Contact</a>
            <button className="relative p-2 text-gray-700 hover:text-blue-600">
              <ShoppingCart size={24} />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-5 h-5 text-xs flex items-center justify-center">3</span>
            </button>
          </nav>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Search */}
        <div className="md:hidden mt-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Search medicines, supplements..."
              className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <Search className="absolute left-3 top-2.5 text-gray-400" size={20} />
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200">
          <nav className="container mx-auto px-4 py-4 space-y-4">
            <a href="#home" className="block text-gray-700 hover:text-blue-600 font-medium">Home</a>
            <a href="#products" className="block text-gray-700 hover:text-blue-600 font-medium">Products</a>
            <a href="#reviews" className="block text-gray-700 hover:text-blue-600 font-medium">Reviews</a>
            <a href="#contact" className="block text-gray-700 hover:text-blue-600 font-medium">Contact</a>
            <button className="flex items-center space-x-2 text-gray-700 hover:text-blue-600">
              <ShoppingCart size={20} />
              <span>Cart (3)</span>
            </button>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;