import React from 'react';
import { Phone, Mail, MapPin, Facebook, Twitter, Instagram, Shield, Truck, CreditCard, Clock } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white">
      {/* Main footer */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="bg-blue-600 p-2 rounded-lg">
                <div className="w-8 h-8 bg-white rounded flex items-center justify-center">
                  <span className="text-blue-600 font-bold text-xl">P</span>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold">Maruthi Pharma</h3>
                <p className="text-sm text-gray-400">Trusted Healthcare Solutions</p>
              </div>
            </div>
            <p className="text-gray-400 mb-4">
              Leading online pharmacy providing quality medications and supplements 
              at affordable prices with fast, secure delivery.
            </p>
            <div className="flex space-x-4">
              <Facebook className="w-5 h-5 text-gray-400 hover:text-white cursor-pointer" />
              <Twitter className="w-5 h-5 text-gray-400 hover:text-white cursor-pointer" />
              <Instagram className="w-5 h-5 text-gray-400 hover:text-white cursor-pointer" />
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-400 hover:text-white">Home</a></li>
              <li><a href="#products" className="text-gray-400 hover:text-white">Products</a></li>
              <li><a href="#reviews" className="text-gray-400 hover:text-white">Reviews</a></li>
              <li><a href="#about" className="text-gray-400 hover:text-white">About Us</a></li>
              <li><a href="#contact" className="text-gray-400 hover:text-white">Contact</a></li>
              <li><a href="#faq" className="text-gray-400 hover:text-white">FAQ</a></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Categories</h4>
            <ul className="space-y-2">
              <li><a href="#vitamins" className="text-gray-400 hover:text-white">Vitamins</a></li>
              <li><a href="#supplements" className="text-gray-400 hover:text-white">Supplements</a></li>
              <li><a href="#minerals" className="text-gray-400 hover:text-white">Minerals</a></li>
              <li><a href="#digestive" className="text-gray-400 hover:text-white">Digestive Health</a></li>
              <li><a href="#pain-relief" className="text-gray-400 hover:text-white">Pain Relief</a></li>
              <li><a href="#skincare" className="text-gray-400 hover:text-white">Skincare</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Us</h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-blue-400" />
                <span className="text-gray-400">+1-800-PHARMA-1</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-blue-400" />
                <span className="text-gray-400">info@maruthipharma.com</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-blue-400" />
                <span className="text-gray-400">123 Healthcare St, Medical City, HC 12345</span>
              </div>
              <div className="flex items-center space-x-3">
                <Clock className="w-5 h-5 text-blue-400" />
                <span className="text-gray-400">24/7 Customer Support</span>
              </div>
            </div>
          </div>
        </div>

        {/* Trust badges */}
        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center space-x-2 text-gray-400">
              <Shield className="w-5 h-5" />
              <span className="text-sm">FDA Approved</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-400">
              <Truck className="w-5 h-5" />
              <span className="text-sm">Free Shipping</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-400">
              <CreditCard className="w-5 h-5" />
              <span className="text-sm">Secure Payments</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-400">
              <Clock className="w-5 h-5" />
              <span className="text-sm">24/7 Support</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gray-800">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 Maruthi Pharma. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#privacy" className="text-gray-400 hover:text-white text-sm">Privacy Policy</a>
              <a href="#terms" className="text-gray-400 hover:text-white text-sm">Terms of Service</a>
              <a href="#returns" className="text-gray-400 hover:text-white text-sm">Return Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;