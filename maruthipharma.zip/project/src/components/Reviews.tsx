import React from 'react';
import { Star, CheckCircle, User } from 'lucide-react';
import { reviews } from '../data/reviews';
import { products } from '../data/products';

const Reviews: React.FC = () => {
  // Get product names for reviews
  const getProductName = (productId: string) => {
    const product = products.find(p => p.id === productId);
    return product?.name || 'Unknown Product';
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            size={16}
            className={`${
              i < rating
                ? 'text-yellow-400 fill-current'
                : 'text-gray-300'
            }`}
          />
        ))}
      </div>
    );
  };

  // Calculate overall statistics
  const totalReviews = reviews.length;
  const averageRating = reviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews;
  const verifiedCount = reviews.filter(review => review.verified).length;

  return (
    <section id="reviews" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            Customer Reviews
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            See what our customers are saying about our products and service
          </p>
          
          {/* Overall stats */}
          <div className="bg-gray-50 rounded-lg p-6 max-w-md mx-auto">
            <div className="flex items-center justify-center space-x-4 mb-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-gray-800">
                  {averageRating.toFixed(1)}
                </div>
                <div className="flex justify-center mb-2">
                  {renderStars(Math.round(averageRating))}
                </div>
                <div className="text-sm text-gray-600">
                  Based on {totalReviews} reviews
                </div>
              </div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center space-x-2 text-green-600">
                <CheckCircle size={16} />
                <span className="text-sm font-medium">
                  {verifiedCount} verified purchases
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map(review => (
            <div key={review.id} className="bg-gray-50 rounded-lg p-6 hover:shadow-lg transition-shadow">
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                    <User className="text-white" size={20} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">
                      {review.customerName}
                    </h4>
                    <div className="flex items-center space-x-2">
                      {renderStars(review.rating)}
                      {review.verified && (
                        <div className="flex items-center space-x-1 text-green-600">
                          <CheckCircle size={12} />
                          <span className="text-xs">Verified</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Product name */}
              <div className="mb-3">
                <span className="text-sm text-blue-600 bg-blue-50 px-2 py-1 rounded-full">
                  {getProductName(review.productId)}
                </span>
              </div>

              {/* Review text */}
              <p className="text-gray-700 mb-4 leading-relaxed">
                "{review.comment}"
              </p>

              {/* Date */}
              <div className="text-sm text-gray-500">
                {formatDate(review.date)}
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <div className="bg-gradient-to-r from-blue-600 to-green-600 text-white rounded-lg p-8 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold mb-4">Join Thousands of Satisfied Customers</h3>
            <p className="mb-6">
              Experience the quality and service that has earned us these amazing reviews
            </p>
            <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
              Shop Now
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Reviews;