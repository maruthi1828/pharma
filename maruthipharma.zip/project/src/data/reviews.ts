import { Review } from '../types';

export const reviews: Review[] = [
  {
    id: '1',
    productId: '1',
    customerName: 'Sarah Johnson',
    rating: 5,
    comment: 'Excellent vitamin D3 supplement. I\'ve been taking it for 3 months and my energy levels have improved significantly.',
    date: '2024-01-15',
    verified: true
  },
  {
    id: '2',
    productId: '2',
    customerName: 'Mike Chen',
    rating: 4,
    comment: 'Good quality fish oil. No fishy aftertaste and easy to swallow capsules.',
    date: '2024-01-10',
    verified: true
  },
  {
    id: '3',
    productId: '5',
    customerName: 'Emily Davis',
    rating: 5,
    comment: 'Amazing probiotic! My digestive issues have completely resolved after using this for 6 weeks.',
    date: '2024-01-08',
    verified: true
  },
  {
    id: '4',
    productId: '3',
    customerName: 'Robert Wilson',
    rating: 5,
    comment: 'Great multivitamin with all essential nutrients. Perfect for daily use.',
    date: '2024-01-05',
    verified: true
  },
  {
    id: '5',
    productId: '4',
    customerName: 'Lisa Thompson',
    rating: 4,
    comment: 'Good calcium supplement. Helps with my bone health concerns.',
    date: '2024-01-03',
    verified: false
  },
  {
    id: '6',
    productId: '1',
    customerName: 'David Brown',
    rating: 5,
    comment: 'Highly recommend this Vitamin D3. Great quality at an affordable price.',
    date: '2024-01-01',
    verified: true
  }
];